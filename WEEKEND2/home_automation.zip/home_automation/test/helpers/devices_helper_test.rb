require 'test_helper'

class DevicesHelperTest < ActionView::TestCase
end
