require 'test_helper'

class RoomCategoriesHelperTest < ActionView::TestCase
end
