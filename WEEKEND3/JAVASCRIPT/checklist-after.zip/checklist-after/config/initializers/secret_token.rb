# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Checklist::Application.config.secret_token = '26f06802dd24025a5963321865a04c0cb17a14618c1d6349ee4fc41cd52c24b4bb972986d8885d1f7852d7f233fda4bcd743f60a2170717c877223c3d0fdd828'
